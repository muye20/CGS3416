package loop;

public class count {
	public static void main(String[] ags) {
		final int MAX_NUM = 100;
		final int VALUE = 5;
		int counter = 0;

		for (int i = 1; i <= MAX_NUM; i++) {
			if ((i % VALUE) == 0) {
				counter++;
				System.out.println(i + " is divisible by " + VALUE);
			}
		}

		System.out.println("There are " + counter + " numbers below " + MAX_NUM
				+ " that are divisible by " + VALUE);
	}
}
