package loop;

public class PrintAsterisks {

	public static void main(String[] ags) {
		final int NUM_OF_ASTERISK = 8;
		final int NUM_OF_ROWS = 8;

		for (int r = 0; r < NUM_OF_ROWS; r++) {
			for (int i = 0; i < NUM_OF_ASTERISK; i++)
				System.out.print("*");

			System.out.println();
		}
	}
}
