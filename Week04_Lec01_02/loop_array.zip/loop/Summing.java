package loop;

public class Summing {

	public static void main(String[] ags) {
		final int MAX_NUM = 100;
		int sum = 0;

		// accumulate sum from 1 to MAX_NUM
		for (int i = 1; i <= MAX_NUM; i++) {
			System.out.println("Add " + i + " to sum");
			sum += i;
		}

		System.out.println("sum = " + sum);
	}
}
