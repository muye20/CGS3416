package loop;

public class Basic {
	public static void main(String[] ags) {
		final int MAX = 10;

		for (int i = 0; i < MAX; i++)
			System.out.printf("%d\t", i);
		System.out.println();

		int j;
		for (j = 0; j < MAX; j++)
			System.out.printf("%d\t", j);
		System.out.println();

		int k = 0;
		for (; k < MAX; k++)
			System.out.printf("%d\t", k);
		System.out.println();

		int l = 0;
		for (; l < MAX;) {
			System.out.printf("%d\t", l);
			l++;
		}
		System.out.println();

		System.out.println("Finished");
	}
}
