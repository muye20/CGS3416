package loop;

public class Array1 {
	public static void main(String[] args) {

		final int SIZE = 10;
		int[] list = new int[SIZE];

		// assign value to each element of the list
		for (int i = 0; i < SIZE; i++)
			list[i] = i * 2; // assign i*2 to the ith element of 'list'

		System.out.println("The list length is " + list.length);

		// print the content of the array 'list'
		for (int i = 0; i < SIZE; i++)
			System.out.printf("list[%d] = %d\n", i, list[i]);

		char[] vowels = { 'a', 'e', 'i', 'o', 'u' }; // size 5
		for (int i = 0; i < vowels.length; i++)
			System.out.printf("vowels[%d] = %c\n", i, vowels[i]);

	}
}
