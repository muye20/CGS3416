package loop;

public class ArrayCopy {
	public static void main(String[] args) {
		final int SIZE = 10;
		int[] list1 = new int[SIZE];
		int[] list2 = new int[SIZE];

		// assign value to each element of the list
		for (int i = 0; i < SIZE; i++)
			list1[i] = i * 2; // assign i*2 to the ith element of 'list1'

		// list2 = list1 will not copy
		for (int i = 0; i < list1.length; i++)
			list2[i] = list1[i];

		// print the content of the array 'list2'
		for (int i = 0; i < SIZE; i++)
			System.out.printf("list[%d] = %d\n", i, list2[i]);

	}
}
