public class FindMaxInArray {
	public static void main(String[] args) {
		int[] list;
		list = new int[10];
		int max;

		for (int i = 0; i < list.length; i++)
			list[i] = i * 2 + 1;

		max = FindMax(list);

		PrintList(list);
		System.out.println("max in the list = " + max);
	}

	public static void PrintList(int[] x) {
		for (int i = 0; i < x.length; i++)
			System.out.printf("%d\t", x[i]);
		System.out.println();
	}

	public static int FindMax(int[] x) {
		int max = x[0];

		for (int i = 1; i < x.length; i++) {
			if (max < x[i])
				max = x[i];
		}

		return max;
	}
}
