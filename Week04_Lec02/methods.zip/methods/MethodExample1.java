public class MethodExample1 {

	public static void main(String[] args) {
		int num1 = 5;
		int num2 = 7;

		int ans1 = Sum(num1, num2);
		int ans2 = Max(num1, num2);

		Echo(num1, num2);
		System.out.println("ans1 = " + ans1);
		System.out.println("ans2 = " + ans2);
		PrintStop();
	}

	public static void Echo(int a, int b) {
		System.out.println("a is " + a);
		System.out.println("b is " + b);
	}

	public static int Sum(int a, int b) {
		return a + b;
	}

	public static int Max(int a, int b) {
		if (a > b)
			return a;
		else
			return b;
	}

	public static void PrintStop() {
		System.out.println("Program Stop Executing");
	}
}
