public class AmbiguousInvocation {

	public static void main(String[] args) {
		int x = 3;
		double y = 3.456;

		Echo(x, y);
		Echo(y, x);
		// Echo(3, 4); // Ambiguous Invocation
	}

	public static void Echo(int input1, double input2) {
		System.out.print("Version 1\t");
		System.out.print("input1 = " + input1);
		System.out.println(" input2 = " + input2);
	}

	public static void Echo(double input1, int input2) {
		System.out.print("Version 2\t");
		System.out.print("input1 = " + input1);
		System.out.println(" input2 = " + input2);
	}
}
