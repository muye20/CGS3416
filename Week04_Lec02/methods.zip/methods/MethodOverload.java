
public class MethodOverload {
	
	public static void main(String[] args) {
	
		int x = 10;
		double y = 3.789;
		char z = 'V';
		
		Echo(x);
		Echo(y);
		Echo(z);
		
	}
	
	public static void Echo(int input){
		System.out.println("(int version) input is " + input);
	}

	public static void Echo(double input){
		System.out.println("(double version) input is " + input);
	}
	
	public static void Echo(char input){
		System.out.println("(char version) input is " + input);
	}	
}
